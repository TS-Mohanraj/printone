// Copyright (c) 2026, Mohanraj and contributors
// For license information, please see license.txt

frappe.ui.form.on('Counter Reading', {

    reading_date: function(frm) {
        run_calculation(frm);
    },

    bnw_count: function(frm) {
        run_calculation(frm);
    },

    color_count: function(frm) {
        run_calculation(frm);
    },

    customer: function(frm) {
        run_calculation(frm);
    },

    contract: function(frm) {
        run_calculation(frm);
    },

    validate: function(frm) {
        // BLOCK SAVE if date is invalid
        if (frm._date_error) {
            frappe.throw("Reading date must be greater than previous reading date");
        }
        let bnw_used = frm.doc.bnw_consumption || 0;
        let color_used = frm.doc.color_consumption || 0;

        let prev_bnw = frm.doc.previous_bnw_consumption || 0;
        let prev_color = frm.doc.previous_color_consumption || 0;

        // Only run if previous exists
        if (prev_bnw > 0 || prev_color > 0) {

            let prev_bnw_90 = prev_bnw * 0.90;
            let prev_bnw_110 = prev_bnw * 1.10;

            let prev_color_90 = prev_color * 0.90;
            let prev_color_110 = prev_color * 1.10;

            // BnW validation
            if (bnw_used < prev_bnw_90) {
                frappe.throw("BnW Consumption too LOW (less than 90% of previous)");
            }

            if (bnw_used > prev_bnw_110) {
                frappe.throw("BnW Consumption too HIGH (more than 110% of previous)");
            }

            // Color validation
            if (color_used < prev_color_90) {
                frappe.throw("Color Consumption too LOW (less than 90% of previous)");
            }

            if (color_used > prev_color_110) {
                frappe.throw("Color Consumption too HIGH (more than 110% of previous)");
            }
        }
    }
});


function run_calculation(frm) {

    if (!frm.doc.customer || !frm.doc.reading_date) return;

    let current_date = frappe.datetime.str_to_obj(frm.doc.reading_date);

    // Get latest previous reading (IMPORTANT: exclude current doc)
    frappe.call({
        method: "frappe.client.get_list",
        args: {
            doctype: "Counter Reading",
            filters: {
                customer: frm.doc.customer,
                name: ["!=", frm.doc.name || ""]
            },
            fields: ["bnw_count", "color_count", "reading_date"],
            order_by: "reading_date desc",
            limit_page_length: 1
        },
        callback: function(r) {

            let prev = r.message.length ? r.message[0] : null;

            let prev_bnw = prev ? (prev.bnw_count || 0) : 0;
            let prev_color = prev ? (prev.color_count || 0) : 0;
            let prev_date = prev ? frappe.datetime.str_to_obj(prev.reading_date) : null;

            // Set previous values
            frm.set_value("previous_bnw", prev_bnw);
            frm.set_value("previous_color", prev_color);
            frm.set_value("previous_reading_date", prev ? prev.reading_date : null);

            let days = 0;

            if (prev_date) {

                days = frappe.datetime.get_diff(current_date, prev_date);
                frm.set_value("days_difference", days);

                // DATE VALIDATION (UI LEVEL)
                if (current_date <= prev_date) {
                    frm._date_error = true;

                    frappe.msgprint({
                        title: "Invalid Date",
                        message: `Reading date must be greater than previous reading date (${prev.reading_date})`,
                        indicator: "red"
                    });

                    return; // stop calculation
                } else {
                    frm._date_error = false;
                }

                //  Minimum 25 days warning (not blocking)
                if (days < 25) {
                    frappe.msgprint(`Warning: Only ${days} days since last reading`);
                }

            } else {
                frm._date_error = false;
                frm.set_value("days_difference", 0);
            }

            

            // Consumption
            let bnw_used = (frm.doc.bnw_count || 0) - prev_bnw;
            let color_used = (frm.doc.color_count || 0) - prev_color;

            frm.set_value("bnw_consumption", bnw_used);
            frm.set_value("color_consumption", color_used);

            // Get contract
            if (!frm.doc.contract) return;

            frappe.call({
                method: "frappe.client.get",
                args: {
                    doctype: "Printer Contract",
                    name: frm.doc.contract
                },
                callback: function(res) {

                    let contract = res.message;

                    let free_bnw = contract.monthly_free_copies_bnw || 0;
                    let free_color = contract.monthly_free_copies_color || 0;

                    let bnw_rate = contract.extra_rate_bnw || 0;
                    let color_rate = contract.extra_rate_color || 0;

                    let allowed_bnw = 0;
                    let allowed_color = 0;
                    let prorated_bnw = 0;
                    let prorated_color = 0;

                    // Allowance logic (same as Python)
                    if (!prev || days >= 30) {
                        allowed_bnw = free_bnw;
                        allowed_color = free_color;
                    } else {
                        prorated_bnw = (free_bnw / 30) * days;
                        prorated_color = (free_color / 30) * days;

                        allowed_bnw = prorated_bnw;
                        allowed_color = prorated_color;
                    }

                    // Billable
                    let bnw_billable = Math.max(0, bnw_used - allowed_bnw);
                    let color_billable = Math.max(0, color_used - allowed_color);

                    // Amount
                    let bnw_amount = bnw_billable * bnw_rate;
                    let color_amount = color_billable * color_rate;

                    // Set values
                    frm.set_value("prorated_bnw", prorated_bnw);
                    frm.set_value("prorated_color", prorated_color);

                    frm.set_value("bnw_billable", Math.floor(bnw_billable));
                    frm.set_value("color_billable", Math.floor(color_billable));

                    frm.set_value("bnw_amount", bnw_amount);
                    frm.set_value("color_amount", color_amount);
                }
            });
        }
    });
}

